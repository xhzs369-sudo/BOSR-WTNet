from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import platform
import subprocess
import sys
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from torch import nn


HERE = Path(__file__).resolve().parent
ROOT = Path(os.environ.get("BOSR_PROJECT_ROOT", HERE.parent))
PAPER = ROOT / "experiments/innovation_search/ecf_wtnet/paper_final_protocol_20260810"
IMPL = PAPER / "implementation"
STATS = PAPER / "metric_statistics"
BOSR_ROOT = ROOT / "experiments/innovation_search/ecf_wtnet/formal_bosr_three_seed_20260814"
PUBLIC_ROOT = ROOT / "experiments/innovation_search/ecf_wtnet/bosr_final_public_test_20260814"
LOCK_PATH = PUBLIC_ROOT / "PUBLIC_TEST_PRESTART_LOCK.json"
PREREG = HERE / "PREREGISTRATION.json"
PRELOCK = HERE / "PRE_RUN_LOCK.json"
RESULT = HERE / "EFFICIENCY_RESULTS.json"
SEED = 20260801
WARMUP = 50
REPEATS = 500

sys.path.insert(0, str(IMPL))
sys.path.insert(0, str(STATS))
sys.path.insert(0, str(BOSR_ROOT))
from formal_common import load_wtnet  # noqa: E402
from complexity_core import count_conv_linear_macs, count_parameters  # noqa: E402
from formal_bosr_head import FormalBOSRHead  # noqa: E402


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def save_json(path: Path, payload: object) -> None:
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def weight_item(lock: dict, group: str) -> dict:
    matches = [item for item in lock["weights"] if int(item["seed"]) == SEED and item["group"] == group]
    if len(matches) != 1:
        raise RuntimeError(f"weight identity failure: {group}")
    item = matches[0]
    path = Path(item["path"])
    if not path.is_file() or sha256(path) != item["sha256"]:
        raise RuntimeError(f"weight hash failure: {group}")
    return {**item, "bytes": path.stat().st_size}


class FrozenInference(nn.Module):
    def __init__(self, parent: nn.Module, head: nn.Module | None = None) -> None:
        super().__init__()
        self.parent = parent
        self.head = head
        self._calibration = None
        self._hook = None if head is None else self.parent.cali.register_forward_hook(self._capture)

    def _capture(self, _module, _inputs, output) -> None:
        self._calibration = output

    def forward(self, image: torch.Tensor) -> torch.Tensor:
        height, width = image.shape[-2:]
        pad_h, pad_w = (-height) % 8, (-width) % 8
        padded = F.pad(image, (0, pad_w, 0, pad_h), mode="reflect") if pad_h or pad_w else image
        output = self.parent(padded)[..., :height, :width]
        if self.head is None:
            return torch.clamp(output, 0.0, 1.0)
        if self._calibration is None:
            raise RuntimeError("WTNet calibration capture failed")
        calibration = self._calibration[..., :height, :width]
        refined, _ = self.head(image, calibration, output)
        return refined


def state_tensor_bytes(model: nn.Module) -> int:
    return int(sum(value.numel() * value.element_size() for value in model.state_dict().values()))


def timed_forward(model: nn.Module, image: torch.Tensor) -> tuple[dict, list[float]]:
    model.eval()
    with torch.inference_mode():
        for _ in range(WARMUP):
            model(image)
        torch.cuda.synchronize(image.device)
        torch.cuda.reset_peak_memory_stats(image.device)
        values = np.empty(REPEATS, dtype=np.float64)
        for index in range(REPEATS):
            torch.cuda.synchronize(image.device)
            start = time.perf_counter_ns()
            model(image)
            torch.cuda.synchronize(image.device)
            values[index] = (time.perf_counter_ns() - start) / 1_000_000.0
    return {
        "warmup": WARMUP,
        "repeats": REPEATS,
        "mean_ms": float(values.mean()),
        "sample_sd_ms": float(values.std(ddof=1)),
        "median_ms": float(np.median(values)),
        "p95_ms": float(np.percentile(values, 95)),
        "fps_from_mean": float(1000.0 / values.mean()),
        "peak_allocated_bytes": int(torch.cuda.max_memory_allocated(image.device)),
        "peak_reserved_bytes": int(torch.cuda.max_memory_reserved(image.device)),
    }, values.tolist()


def build_group(lock: dict, group: str, device: torch.device) -> tuple[FrozenInference, list[dict]]:
    parent_info = weight_item(lock, "WTNET-50")
    parent = load_wtnet(device, Path(parent_info["path"])).eval()
    if group == "WTNet-50":
        return FrozenInference(parent).to(device).eval(), [parent_info]
    if group != "BOSR-WTNet":
        raise ValueError(group)
    head_info = weight_item(lock, "BOSR-ONLY")
    head = FormalBOSRHead("BOSR-ONLY").to(device).eval()
    payload = torch.load(head_info["path"], map_location="cpu", weights_only=False)
    head.load_state_dict(payload["params"], strict=True)
    parent.requires_grad_(False)
    return FrozenInference(parent, head).to(device).eval(), [parent_info, head_info]


def prepare() -> None:
    if PRELOCK.exists() or RESULT.exists():
        raise RuntimeError("pre-run lock or result already exists")
    lock = json.loads(LOCK_PATH.read_text(encoding="utf-8"))
    parent_info = weight_item(lock, "WTNET-50")
    bosr_info = weight_item(lock, "BOSR-ONLY")
    files = [PREREG, Path(__file__), LOCK_PATH, IMPL / "formal_common.py", STATS / "complexity_core.py", BOSR_ROOT / "formal_bosr_head.py", Path(parent_info["path"]), Path(bosr_info["path"])]
    save_json(PRELOCK, {
        "status": "AUTHORIZED_FOR_DATA_FREE_EFFICIENCY_MEASUREMENT",
        "created_unix": time.time(),
        "files": [{"path": str(path), "bytes": path.stat().st_size, "sha256": sha256(path)} for path in files],
        "dataset_images_read": 0,
        "public_test_images_read": 0,
        "model_parameter_updates": 0
    })
    print(PRELOCK)


def verify_prelock() -> None:
    lock = json.loads(PRELOCK.read_text(encoding="utf-8"))
    for item in lock["files"]:
        path = Path(item["path"])
        if not path.is_file() or path.stat().st_size != int(item["bytes"]) or sha256(path) != item["sha256"]:
            raise RuntimeError(f"pre-run hash failure: {path}")


def nvidia_smi() -> str:
    command = ["nvidia-smi", "--query-gpu=name,driver_version,memory.total,pstate,temperature.gpu", "--format=csv,noheader"]
    return subprocess.check_output(command, text=True, encoding="utf-8", errors="replace").strip()


def run() -> None:
    verify_prelock()
    if RESULT.exists():
        raise RuntimeError("result already exists")
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA is required")
    lock = json.loads(LOCK_PATH.read_text(encoding="utf-8"))
    device = torch.device("cuda:0")
    torch.manual_seed(20260815)
    image = torch.linspace(0.0, 1.0, 3 * 420 * 420, dtype=torch.float32, device=device).reshape(1, 3, 420, 420)
    results, raw_rows = [], []
    for group in ("WTNet-50", "BOSR-WTNet"):
        torch.cuda.empty_cache()
        model, checkpoint_items = build_group(lock, group, device)
        counts = count_parameters(model)
        macs = count_conv_linear_macs(model, image)
        timing, raw = timed_forward(model, image)
        added = 0 if model.head is None else sum(parameter.numel() for parameter in model.head.parameters())
        record = {
            "group": group,
            "seed": SEED,
            **counts,
            "added_head_parameters": int(added),
            "state_tensor_bytes": state_tensor_bytes(model),
            "checkpoint_file_bytes_total": int(sum(int(item["bytes"]) for item in checkpoint_items)),
            **macs,
            **timing,
            "checkpoint_sha256": [item["sha256"] for item in checkpoint_items]
        }
        results.append(record)
        raw_rows.extend({"group": group, "repeat": i + 1, "latency_ms": value} for i, value in enumerate(raw))
        print(f"{group}: {timing['mean_ms']:.4f} ms; {counts['parameters_total']} parameters", flush=True)
        del model
        torch.cuda.empty_cache()
    base, bosr = results
    delta = {
        "added_parameters": bosr["parameters_total"] - base["parameters_total"],
        "parameter_increase_percent": 100.0 * (bosr["parameters_total"] - base["parameters_total"]) / base["parameters_total"],
        "added_counted_macs": bosr["counted_macs"] - base["counted_macs"],
        "counted_macs_increase_percent": 100.0 * (bosr["counted_macs"] - base["counted_macs"]) / base["counted_macs"],
        "latency_increase_ms": bosr["mean_ms"] - base["mean_ms"],
        "latency_increase_percent": 100.0 * (bosr["mean_ms"] - base["mean_ms"]) / base["mean_ms"],
        "peak_allocated_increase_bytes": bosr["peak_allocated_bytes"] - base["peak_allocated_bytes"]
    }
    environment = {
        "timestamp_unix": time.time(),
        "hostname": platform.node(),
        "platform": platform.platform(),
        "python": sys.version,
        "torch": torch.__version__,
        "cuda_runtime": torch.version.cuda,
        "cudnn": torch.backends.cudnn.version(),
        "gpu": torch.cuda.get_device_name(0),
        "nvidia_smi": nvidia_smi(),
        "dataset_images_read": 0,
        "public_test_images_read": 0,
        "model_parameter_updates": 0
    }
    save_json(RESULT, {"status": "COMPLETE_DATA_FREE_BOSR_EFFICIENCY", "environment": environment, "results": results, "delta": delta})
    with (HERE / "EFFICIENCY_RAW_LATENCY.csv").open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=("group", "repeat", "latency_ms")); writer.writeheader(); writer.writerows(raw_rows)
    print(RESULT)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=("prepare", "run"))
    args = parser.parse_args()
    prepare() if args.mode == "prepare" else run()


if __name__ == "__main__":
    main()
