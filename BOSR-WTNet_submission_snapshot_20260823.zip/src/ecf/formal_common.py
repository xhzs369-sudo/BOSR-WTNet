"""Shared, train-360-only utilities for the frozen ECF-WTNet formal groups.

This module deliberately exposes no development/test manifest.  Formal runners
using it cannot discover CEC public test, Endo4IE or RLE paths.
"""
from __future__ import annotations

import csv
import hashlib
import json
import os
import random
import sys
from pathlib import Path
from typing import Any

import cv2
import numpy as np
import torch


ROOT = Path(os.environ.get("BOSR_PROJECT_ROOT", Path(__file__).resolve().parents[3]))
PROTOCOL_ROOT = ROOT / "experiments/innovation_search/ecf_wtnet/paper_final_protocol_20260810"
IMPLEMENTATION_ROOT = PROTOCOL_ROOT / "implementation"
RUN_ROOT = PROTOCOL_ROOT / "formal_engineering_runs"
REFERENCE_ROOT = ROOT / "experiments/innovation_search/ecf_wtnet/advisor_confirmation_single_seed"
THREE_SEED_ROOT = ROOT / "experiments/innovation_search/ecf_wtnet/exploratory_three_seed"
WTNET_ROOT = ROOT / "baselines/WTNet"
TRAIN_MANIFEST = ROOT / "datasets/CEC/internal_split_seed20260731/train_manifest.csv"
TRAIN_MANIFEST_SHA256 = "0739c644764c7d0c28c6302110725f1b819830d8277cc77fe714f9351a654fed"
PROTOCOL_ID = "ECF_WTNET_FINAL_20260810_R2_ENGINEERING_R1"
SEEDS = (20260801, 20260802, 20260803)
HEAD_GROUPS = ("WTNET-GENERIC", "ECF-GLOBAL", "ECF-ALPHA", "ECF-BETA", "ECF-FULL")


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def atomic_torch_save(payload: dict[str, Any], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    torch.save(payload, temporary)
    os.replace(temporary, path)


def atomic_json_save(payload: dict[str, Any], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.replace(temporary, path)


def train_rows() -> list[dict[str, str]]:
    if sha256_file(TRAIN_MANIFEST) != TRAIN_MANIFEST_SHA256:
        raise RuntimeError("train-360 manifest hash mismatch")
    with TRAIN_MANIFEST.open("r", encoding="utf-8-sig", newline="") as stream:
        rows = list(csv.DictReader(stream))
    if len(rows) != 360 or any(row.get("split") != "train" for row in rows):
        raise RuntimeError("train-360 manifest structure mismatch")
    forbidden = ("/test/", "\\test\\", "endo4ie", "rle", "val_manifest")
    for row in rows:
        joined = (row["input_path"] + row["gt_path"]).lower()
        if any(token in joined for token in forbidden):
            raise RuntimeError("sealed or non-training path detected")
    return rows


def read_rgb(path: str | Path) -> np.ndarray:
    raw = np.fromfile(str(path), dtype=np.uint8)
    bgr = cv2.imdecode(raw, cv2.IMREAD_COLOR)
    if bgr is None:
        raise RuntimeError(f"unreadable training image: {path}")
    return cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB).astype(np.float32) / 255.0


def seed_all(seed: int) -> None:
    if seed not in SEEDS:
        raise ValueError(f"seed must be one of {SEEDS}")
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.benchmark = False


def capture_rng_state(loader_generator: torch.Generator) -> dict[str, Any]:
    return {
        "python": random.getstate(),
        "numpy": np.random.get_state(),
        "torch_cpu": torch.get_rng_state(),
        "torch_cuda": torch.cuda.get_rng_state_all() if torch.cuda.is_available() else [],
        "loader_generator": loader_generator.get_state(),
    }


def restore_rng_state(state: dict[str, Any], loader_generator: torch.Generator) -> None:
    random.setstate(state["python"])
    np.random.set_state(state["numpy"])
    torch.set_rng_state(state["torch_cpu"])
    if torch.cuda.is_available() and state.get("torch_cuda"):
        torch.cuda.set_rng_state_all(state["torch_cuda"])
    loader_generator.set_state(state["loader_generator"])


def existing_parent_and_cache(seed: int) -> tuple[Path, Path]:
    if seed == 20260801:
        parent = REFERENCE_ROOT / "matched_parent/epoch_50_last.pt"
        cache = REFERENCE_ROOT / "matched_parent/train_intermediates"
    elif seed in (20260802, 20260803):
        base = THREE_SEED_ROOT / f"seed_{seed}/matched_parent"
        parent = base / "epoch_50_last.pt"
        cache = base / "train_intermediates"
    else:
        raise ValueError(f"seed must be one of {SEEDS}")
    if not parent.is_file():
        raise RuntimeError(f"missing frozen seed-specific parent: {parent}")
    expected_names = {Path(row["filename"]).stem + ".npz" for row in train_rows()}
    actual_names = {path.name for path in cache.glob("*.npz")}
    if actual_names != expected_names:
        raise RuntimeError(
            f"training cache identity mismatch for seed {seed}: "
            f"expected={len(expected_names)}, actual={len(actual_names)}"
        )
    return parent, cache


def load_wtnet(device: torch.device, checkpoint: Path | None = None) -> torch.nn.Module:
    sys.path.insert(0, str(WTNET_ROOT))
    from basicsr.models.archs.WTNet_arch import WTNet

    model = WTNet().to(device)
    if checkpoint is not None:
        obj = torch.load(checkpoint, map_location="cpu", weights_only=False)
        state = obj.get("params", obj.get("model", obj)) if isinstance(obj, dict) else obj
        model.load_state_dict(state, strict=True)
    return model


def group_run_dir(group: str, seed: int) -> Path:
    if group not in ("WTNET-100",) + HEAD_GROUPS:
        raise ValueError(f"unsupported formal group: {group}")
    if seed not in SEEDS:
        raise ValueError(f"unsupported seed: {seed}")
    return RUN_ROOT / f"seed_{seed}" / group.lower().replace("-", "_")


def checkpoint_identity(group: str, seed: int) -> dict[str, Any]:
    return {
        "protocol_id": PROTOCOL_ID,
        "group": group,
        "seed": seed,
        "train_manifest_sha256": TRAIN_MANIFEST_SHA256,
    }


def assert_checkpoint_identity(payload: dict[str, Any], group: str, seed: int) -> None:
    expected = checkpoint_identity(group, seed)
    actual = payload.get("identity")
    if actual != expected:
        raise RuntimeError(f"resume identity mismatch: expected={expected}, actual={actual}")
