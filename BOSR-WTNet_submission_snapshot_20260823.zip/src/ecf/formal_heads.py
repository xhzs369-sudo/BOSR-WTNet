"""Frozen parameter-matched heads for the ECF-WTNet comparison matrix."""
from __future__ import annotations

import sys
from pathlib import Path

import torch
from torch import nn

from formal_common import HEAD_GROUPS, REFERENCE_ROOT


sys.path.insert(0, str(REFERENCE_ROOT))
from ecf_model import DepthwiseResidualBlock, ECFFeedbackHead  # noqa: E402


class FormalECFHead(ECFFeedbackHead):
    """Exact ECF-FULL architecture with preregistered operation ablations."""

    def __init__(self, group: str, width: int = 24, coefficient_bound: float = 0.10) -> None:
        if group not in ("ECF-GLOBAL", "ECF-ALPHA", "ECF-BETA", "ECF-FULL"):
            raise ValueError(f"invalid ECF group: {group}")
        super().__init__(width=width, coefficient_bound=coefficient_bound)
        self.group = group

    def forward(
        self, i0: torch.Tensor, ic: torch.Tensor, i1: torch.Tensor
    ) -> tuple[torch.Tensor, dict[str, torch.Tensor]]:
        dc = ic - i0
        db = i1 - ic
        features = torch.cat((i0, ic, i1, dc, db), dim=1)
        logits = self.output(self.body(self.stem(features)))
        if self.group == "ECF-GLOBAL":
            logits = logits.mean(dim=(-2, -1), keepdim=True).expand_as(logits)
        coeff = self.coefficient_bound * torch.tanh(logits)
        alpha, beta = coeff[:, 0:1], coeff[:, 1:2]
        if self.group == "ECF-ALPHA":
            beta = torch.zeros_like(beta)
        elif self.group == "ECF-BETA":
            alpha = torch.zeros_like(alpha)
        output = torch.clamp(i1 + alpha * dc + beta * db, 0.0, 1.0)
        return output, {"alpha": alpha, "beta": beta}


class GenericResidualHead(nn.Module):
    """Parameter-matched ordinary RGB residual control using the same 15 channels."""

    def __init__(self, width: int = 24, residual_bound: float = 0.10) -> None:
        super().__init__()
        self.residual_bound = float(residual_bound)
        self.stem = nn.Sequential(nn.Conv2d(15, width, 3, padding=1), nn.GELU())
        self.body = nn.Sequential(DepthwiseResidualBlock(width), DepthwiseResidualBlock(width))
        self.output = nn.Conv2d(width, 3, 1)
        nn.init.zeros_(self.output.weight)
        nn.init.zeros_(self.output.bias)

    def forward(
        self, i0: torch.Tensor, ic: torch.Tensor, i1: torch.Tensor
    ) -> tuple[torch.Tensor, dict[str, torch.Tensor]]:
        dc = ic - i0
        db = i1 - ic
        features = torch.cat((i0, ic, i1, dc, db), dim=1)
        residual = self.residual_bound * torch.tanh(self.output(self.body(self.stem(features))))
        output = torch.clamp(i1 + residual, 0.0, 1.0)
        return output, {"residual": residual}


def build_head(group: str) -> nn.Module:
    if group not in HEAD_GROUPS:
        raise ValueError(f"group must be one of {HEAD_GROUPS}")
    if group == "WTNET-GENERIC":
        return GenericResidualHead()
    return FormalECFHead(group)


def parameter_count(model: nn.Module) -> int:
    return sum(parameter.numel() for parameter in model.parameters())

