from __future__ import annotations

import os
import sys
import unittest
from pathlib import Path

import torch

HERE = Path(__file__).resolve().parent
ROOT = Path(os.environ.get("BOSR_PROJECT_ROOT", Path(__file__).resolve().parents[3]))
sys.path[:0] = [
    str(HERE.parent / "bosr"),
    str(HERE.parent / "ecf"),
]
from formal_bosr_head import FormalBOSRHead
from formal_heads import build_head


class PublicProtocolTests(unittest.TestCase):
    def test_bosr_identity_and_range(self):
        model = FormalBOSRHead("BOSR-ONLY")
        i0, ic, i1 = [torch.rand(1, 3, 24, 24) for _ in range(3)]
        out, diag = model(i0, ic, i1)
        self.assertTrue(torch.equal(out, torch.clamp(i1, 0, 1)))
        self.assertEqual(float(diag["alpha"].abs().max()), 0.0)
        self.assertEqual(float(diag["beta"].abs().max()), 0.0)
        self.assertGreaterEqual(float(out.min()), 0.0)
        self.assertLessEqual(float(out.max()), 1.0)

    def test_all_heads_construct(self):
        self.assertIsNotNone(build_head("WTNET-GENERIC"))
        self.assertIsNotNone(build_head("ECF-FULL"))
        self.assertIsNotNone(FormalBOSRHead("BOSR-ONLY"))
        self.assertIsNotNone(FormalBOSRHead("ECF+BOSR"))


if __name__ == "__main__":
    unittest.main()
