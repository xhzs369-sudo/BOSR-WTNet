from __future__ import annotations

import csv
import hashlib
import json
import sys
from pathlib import Path

import numpy as np

HERE, SEEDS = Path(__file__).resolve().parent, (20260801, 20260802, 20260803)
RESULTS = HERE / "results"
SOURCE, ACCESS = RESULTS / "PUBLIC_TEST_ALL_GROUPS_PER_IMAGE.csv", RESULTS / "PUBLIC_TEST_ACCESS.json"
ANALYSIS, DECISION, REPORT = RESULTS / "PUBLIC_TEST_ANALYSIS.json", RESULTS / "PUBLIC_TEST_DECISION.json", RESULTS / "PUBLIC_TEST_REPORT_ZH.md"
GROUPS = ("WTNet-50", "WTNet-100", "GenericHead", "ECF", "BOSR-WTNet", "ECF+BOSR")
METRICS, HIGHER = ("mse", "psnr_db", "ssim", "delta_e00"), {"mse": False, "psnr_db": True, "ssim": True, "delta_e00": False}
sys.path.insert(0, str(HERE.parent / "metrics"))
from statistics_core import paired_percentile_bootstrap


def sha(path: Path) -> str: return hashlib.sha256(path.read_bytes()).hexdigest()


def relative_ci(candidate: np.ndarray, control: np.ndarray) -> dict:
    c, b = candidate.mean(axis=0), control.mean(axis=0)
    point = (b.mean() - c.mean()) / b.mean() * 100
    rng, draws = np.random.default_rng(20260814), np.empty(10000)
    for start in range(0, 10000, 1000):
        ix = rng.integers(0, 100, size=(1000, 100)); bm, cm = b[ix].mean(1), c[ix].mean(1)
        draws[start:start + 1000] = (bm - cm) / bm * 100
    low, high = np.percentile(draws, [2.5, 97.5])
    return {"relative_improvement_percent": float(point), "ci95_low": float(low), "ci95_high": float(high), "n": 100, "resamples": 10000, "seed": 20260814}


def main() -> None:
    if any(path.exists() for path in (ANALYSIS, DECISION, REPORT)): raise RuntimeError("analysis output exists")
    access = json.loads(ACCESS.read_text(encoding="utf-8"))
    if access.get("status") != "COMPLETE_ONE_PASS_CEC_PUBLIC_TEST" or access.get("result_sha256") != sha(SOURCE): raise RuntimeError("access lock mismatch")
    with SOURCE.open("r", encoding="utf-8-sig", newline="") as stream: rows = list(csv.DictReader(stream))
    table = {(int(r["seed"]), r["group"], r["filename"]): r for r in rows}; names = [f"{i}.png" for i in range(100)]
    if len(rows) != 1800 or len(table) != 1800: raise RuntimeError("matrix mismatch")
    def matrix(group, metric): return np.asarray([[float(table[(seed, group, name)][metric]) for name in names] for seed in SEEDS])
    summary = {}
    for group in GROUPS:
        summary[group] = {}
        for metric in METRICS:
            means = matrix(group, metric).mean(1)
            summary[group][metric] = {"seed_means": means.tolist(), "three_seed_mean": float(means.mean()), "between_seed_sample_sd": float(means.std(ddof=1))}
    pairs = (("BOSR-WTNet", "WTNet-50"), ("BOSR-WTNet", "ECF"), ("BOSR-WTNet", "GenericHead"), ("ECF+BOSR", "BOSR-WTNet"), ("WTNet-100", "WTNet-50"))
    comparisons = {}
    for candidate, control in pairs:
        result = comparisons.setdefault(f"{candidate}_vs_{control}", {})
        for metric in METRICS:
            cand, ctrl = matrix(candidate, metric), matrix(control, metric); diff = cand - ctrl
            entry = {"seed_mean_differences": diff.mean(1).tolist(), "aggregate_image_bootstrap": paired_percentile_bootstrap(diff.mean(0), seed=20260814), "favorable_images": int(np.sum(diff.mean(0) > 0 if HIGHER[metric] else diff.mean(0) < 0))}
            if metric in ("mse", "delta_e00"): entry["relative_improvement"] = relative_ci(cand, ctrl)
            result[metric] = entry
    primary = comparisons["BOSR-WTNet_vs_WTNet-50"]
    checks = {
        "mse_relative_ci_lower_above_zero": primary["mse"]["relative_improvement"]["ci95_low"] > 0,
        "psnr_ci_lower_above_zero": primary["psnr_db"]["aggregate_image_bootstrap"]["ci95_low"] > 0,
        "psnr_positive_all_seeds": all(value > 0 for value in primary["psnr_db"]["seed_mean_differences"]),
        "ssim_ci_lower_noninferior": primary["ssim"]["aggregate_image_bootstrap"]["ci95_low"] >= -0.001,
        "delta_e_relative_ci_lower_at_least_minus_1pct": primary["delta_e00"]["relative_improvement"]["ci95_low"] >= -1,
    }
    if all(checks.values()): status = "STRONG_INDEPENDENT_TEST_SUPPORT"
    elif primary["mse"]["relative_improvement"]["relative_improvement_percent"] > 0 and primary["psnr_db"]["aggregate_image_bootstrap"]["mean"] > 0 and checks["ssim_ci_lower_noninferior"] and checks["delta_e_relative_ci_lower_at_least_minus_1pct"]: status = "DIRECTIONAL_INDEPENDENT_TEST_SUPPORT_ONLY"
    else: status = "FINAL_PUBLIC_TEST_DOES_NOT_SUPPORT_PRIMARY_CLAIM"
    payload = {"status": "PUBLIC_TEST_ANALYSIS_COMPLETE", "group_summary": summary, "comparisons": comparisons, "checks": checks, "sealed_other_data": {"Endo4IE": 0, "RLE_new_access": 0}}
    ANALYSIS.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    decision = {"status": status, "passed_strong_support": status == "STRONG_INDEPENDENT_TEST_SUPPORT", "checks": checks, "primary": primary, "post_test_policy": "Final evidence; no public-test-driven tuning or retraining is permitted."}
    DECISION.write_text(json.dumps(decision, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    mse, psnr, ssim, de = primary["mse"]["relative_improvement"], primary["psnr_db"]["aggregate_image_bootstrap"], primary["ssim"]["aggregate_image_bootstrap"], primary["delta_e00"]["relative_improvement"]
    lines = ["# BOSR-WTNet CEC公共测试最终报告", "", f"**判定：{status}**", "", "## BOSR-WTNet相对WTNet-50", "", f"- MSE相对改善：{mse['relative_improvement_percent']:.4f}%（95% CI {mse['ci95_low']:.4f}% 至 {mse['ci95_high']:.4f}%）", f"- PSNR差值：{psnr['mean']:+.6f} dB（95% CI {psnr['ci95_low']:+.6f} 至 {psnr['ci95_high']:+.6f}）", f"- SSIM差值：{ssim['mean']:+.8f}（95% CI {ssim['ci95_low']:+.8f} 至 {ssim['ci95_high']:+.8f}）", f"- DeltaE00相对改善：{de['relative_improvement_percent']:.4f}%（95% CI {de['ci95_low']:.4f}% 至 {de['ci95_high']:.4f}%）", "", "测试结果不得用于继续调参或重训模型。"]
    REPORT.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(json.dumps({"status": status, "passed": decision["passed_strong_support"], "checks": checks}, ensure_ascii=False))


if __name__ == "__main__": main()
