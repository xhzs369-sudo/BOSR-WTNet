"""Complete the preregistered regional analysis from the frozen 1800-row CSV."""
from __future__ import annotations

import csv
import json
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
SOURCE = HERE / "results/PUBLIC_TEST_ALL_GROUPS_PER_IMAGE.csv"
OUTPUT = HERE / "results/PUBLIC_TEST_REGIONAL_ANALYSIS.json"
SEEDS = (20260801, 20260802, 20260803)
sys.path.insert(0, str(HERE.parent / "metrics"))
from statistics_core import paired_percentile_bootstrap


def main() -> None:
    if OUTPUT.exists():
        raise RuntimeError("regional analysis already exists")
    with SOURCE.open("r", encoding="utf-8-sig", newline="") as stream:
        rows = list(csv.DictReader(stream))
    table = {(int(row["seed"]), row["group"], row["filename"]): row for row in rows}
    names = [f"{index}.png" for index in range(100)]
    results = {}
    for region in ("dark", "normal", "highlight"):
        common_names = [name for name in names if all(table[(seed, "BOSR-WTNet", name)][f"{region}_computable"].lower() == "true" and table[(seed, "WTNet-50", name)][f"{region}_computable"].lower() == "true" for seed in SEEDS)]
        differences = np.asarray([[float(table[(seed, "BOSR-WTNet", name)][f"{region}_luminance_mae"]) - float(table[(seed, "WTNet-50", name)][f"{region}_luminance_mae"]) for name in common_names] for seed in SEEDS])
        control = np.asarray([[float(table[(seed, "WTNet-50", name)][f"{region}_luminance_mae"]) for name in common_names] for seed in SEEDS])
        aggregate = differences.mean(axis=0)
        absolute = paired_percentile_bootstrap(aggregate, seed=20260814)
        relative_mean = float(-aggregate.mean() / control.mean() * 100.0)
        results[region] = {"computable_images": len(common_names), "signed_definition": "BOSR-WTNet minus WTNet-50 luminance MAE", "absolute_difference_bootstrap": absolute, "relative_improvement_percent_descriptive": relative_mean}
    payload = {"status": "PREREGISTERED_PUBLIC_TEST_REGIONAL_ANALYSIS_COMPLETE", "decision_impact": "descriptive_secondary_only; primary frozen decision unchanged", "regions": results, "public_test_image_re_reads": 0, "source_rows": 1800}
    OUTPUT.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(payload, ensure_ascii=False))


if __name__ == "__main__":
    main()
