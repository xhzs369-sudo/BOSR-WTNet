"""One-pass evaluation of all frozen groups on 100-pair CEC public test."""
from __future__ import annotations

import csv
import hashlib
import json
import os
import sys
from pathlib import Path

import cv2
import numpy as np
import torch
import torch.nn.functional as F

HERE = Path(__file__).resolve().parent
ROOT = Path(os.environ.get("BOSR_PROJECT_ROOT", Path(__file__).resolve().parents[3]))
LOCK = HERE / "PUBLIC_TEST_PRESTART_LOCK.json"
OUT = HERE / "results"
FINAL, ACCESS, JOURNAL = OUT / "PUBLIC_TEST_ALL_GROUPS_PER_IMAGE.csv", OUT / "PUBLIC_TEST_ACCESS.json", OUT / "PUBLIC_TEST_IN_PROGRESS.ndjson"
INPUT, GT = ROOT / "datasets/CEC/test/input_under", ROOT / "datasets/CEC/test/gt"
SEEDS = (20260801, 20260802, 20260803)
GROUPS = ("WTNet-50", "WTNet-100", "GenericHead", "ECF", "BOSR-WTNet", "ECF+BOSR")
sys.path[:0] = [
    str(ROOT / "experiments/innovation_search/ecf_wtnet/formal_bosr_three_seed_20260814"),
    str(ROOT / "experiments/innovation_search/ecf_wtnet/paper_final_protocol_20260810/implementation"),
    str(ROOT / "experiments/innovation_search/ecf_wtnet/paper_final_protocol_20260810/metric_statistics"),
    str(ROOT / "experiments/innovation_search/ecf_wtnet/advisor_confirmation_single_seed"),
]
from formal_bosr_head import FormalBOSRHead
from formal_heads import build_head
from ecf_common import CaptureCalibration, load_wtnet
from metrics_core import calculate_full_reference_metrics, calculate_region_luminance_metrics

FIELDS = ["seed", "group", "filename", "mse", "psnr_db", "ssim", "delta_e00", "dark_pixel_count", "dark_computable", "dark_luminance_mae", "normal_pixel_count", "normal_computable", "normal_luminance_mae", "highlight_pixel_count", "highlight_computable", "highlight_luminance_mae", "alpha_abs_mean", "beta_abs_mean", "u_abs_mean", "preclip_out_of_range_fraction", "final_out_of_range_fraction"]


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def read_rgb(path: Path) -> np.ndarray:
    bgr = cv2.imdecode(np.fromfile(str(path), dtype=np.uint8), cv2.IMREAD_COLOR)
    if bgr is None:
        raise RuntimeError(f"unreadable image: {path}")
    return cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB).astype(np.float32) / 255.0


def save_rgb(path: Path, rgb: np.ndarray) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    bgr = cv2.cvtColor(np.clip(np.rint(rgb * 255.0), 0, 255).astype(np.uint8), cv2.COLOR_RGB2BGR)
    ok, encoded = cv2.imencode(".png", bgr)
    if not ok:
        raise RuntimeError(f"PNG encoding failed: {path}")
    encoded.tofile(str(path))


def infer(model, image: torch.Tensor) -> torch.Tensor:
    h, w = image.shape[-2:]
    ph, pw = (-h) % 8, (-w) % 8
    x = F.pad(image, (0, pw, 0, ph), mode="reflect") if ph or pw else image
    return model(x)[..., :h, :w]


def get_weight(lock: dict, seed: int, group: str) -> Path:
    match = [Path(item["path"]) for item in lock["weights"] if item["seed"] == seed and item["group"] == group]
    if len(match) != 1:
        raise RuntimeError(f"weight identity failure: {seed} {group}")
    return match[0]


def make_record(seed: int, group: str, name: str, output: torch.Tensor, gt: np.ndarray, diag=None) -> dict:
    pred = np.clip(output[0].permute(1, 2, 0).detach().cpu().numpy().astype(np.float64), 0, 1)
    row = {"seed": seed, "group": group, "filename": name}
    row.update(calculate_full_reference_metrics(pred, gt))
    regions = calculate_region_luminance_metrics(pred, gt)
    for region in ("dark", "normal", "highlight"):
        for key in ("pixel_count", "computable", "luminance_mae"):
            row[f"{region}_{key}"] = regions[region][key]
    for key in ("alpha_abs_mean", "beta_abs_mean", "u_abs_mean", "preclip_out_of_range_fraction", "final_out_of_range_fraction"):
        row[key] = float("nan")
    if diag:
        for key in ("alpha", "beta", "u"):
            if key in diag:
                row[f"{key}_abs_mean"] = float(diag[key].abs().mean().cpu())
        pre = diag.get("stage_preclip")
        if pre is not None:
            row["preclip_out_of_range_fraction"] = float(((pre < 0) | (pre > 1)).float().mean().cpu())
        row["final_out_of_range_fraction"] = float(((output < 0) | (output > 1)).float().mean().cpu())
    return row


def main() -> None:
    if OUT.exists():
        raise RuntimeError("public-test output path already exists")
    lock = json.loads(LOCK.read_text(encoding="utf-8"))
    if lock.get("status") != "AUTHORIZED_FOR_ONE_PASS_CEC_PUBLIC_TEST":
        raise RuntimeError("invalid public-test lock")
    for item in lock["locked_files"] + lock["weights"]:
        path = Path(item["path"])
        if not path.is_file() or sha(path) != item["sha256"]:
            raise RuntimeError(f"post-lock hash mismatch: {path}")
    filenames = [f"{i}.png" for i in range(100)]
    OUT.mkdir(parents=True)
    records, device = [], torch.device("cuda")
    with torch.inference_mode(), JOURNAL.open("x", encoding="utf-8") as journal:
        for seed in SEEDS:
            parent50 = load_wtnet(device, get_weight(lock, seed, "WTNET-50")).eval()
            parent100 = load_wtnet(device, get_weight(lock, seed, "WTNET-100")).eval()
            capture = CaptureCalibration(parent50)
            generic, ecf = build_head("WTNET-GENERIC").to(device).eval(), build_head("ECF-FULL").to(device).eval()
            generic.load_state_dict(torch.load(get_weight(lock, seed, "WTNET-GENERIC"), map_location="cpu", weights_only=False)["params"], strict=True)
            ecf.load_state_dict(torch.load(get_weight(lock, seed, "ECF-FULL"), map_location="cpu", weights_only=False)["params"], strict=True)
            bosr, combo = FormalBOSRHead("BOSR-ONLY").to(device).eval(), FormalBOSRHead("ECF+BOSR").to(device).eval()
            bosr.load_state_dict(torch.load(get_weight(lock, seed, "BOSR-ONLY"), map_location="cpu", weights_only=False)["params"], strict=True)
            combo.load_state_dict(torch.load(get_weight(lock, seed, "ECF+BOSR"), map_location="cpu", weights_only=False)["params"], strict=True)
            for index, name in enumerate(filenames, 1):
                low, gt = read_rgb(INPUT / name), read_rgb(GT / name)
                if low.shape != gt.shape:
                    raise RuntimeError(f"shape mismatch: {name}")
                image = torch.from_numpy(low).permute(2, 0, 1).unsqueeze(0).to(device)
                out50 = infer(parent50, image)
                ic = capture.value
                if ic is None:
                    raise RuntimeError("ECM capture failed")
                ic = ic[..., :image.shape[-2], :image.shape[-1]]
                outputs = {
                    "WTNet-50": (torch.clamp(out50, 0, 1), None),
                    "WTNet-100": (torch.clamp(infer(parent100, image), 0, 1), None),
                    "GenericHead": generic(image, ic, out50),
                    "ECF": ecf(image, ic, out50),
                    "BOSR-WTNet": bosr(image, ic, out50),
                    "ECF+BOSR": combo(image, ic, out50),
                }
                if seed == 20260801:
                    if index == 1:
                        save_rgb(OUT / "qualitative_cache/input" / name, low)
                        save_rgb(OUT / "qualitative_cache/gt" / name, gt)
                    else:
                        save_rgb(OUT / "qualitative_cache/input" / name, low)
                        save_rgb(OUT / "qualitative_cache/gt" / name, gt)
                for group in GROUPS:
                    value = outputs[group]
                    output, diag = value if isinstance(value, tuple) else (value, None)
                    row = make_record(seed, group, name, output, gt, diag)
                    records.append(row); journal.write(json.dumps(row, allow_nan=True) + "\n")
                    if seed == 20260801:
                        pred = output[0].permute(1, 2, 0).detach().cpu().numpy()
                        save_rgb(OUT / "qualitative_cache" / group / name, pred)
                journal.flush()
                print(f"seed={seed} image={index}/100", flush=True)
            capture.close(); del parent50, parent100, generic, ecf, bosr, combo
            torch.cuda.empty_cache()
    if len(records) != 1800 or len({(r["seed"], r["group"], r["filename"]) for r in records}) != 1800:
        raise RuntimeError("public-test completeness failure")
    temporary = FINAL.with_suffix(".csv.tmp")
    with temporary.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=FIELDS); writer.writeheader(); writer.writerows(records)
    os.replace(temporary, FINAL); JOURNAL.unlink()
    ACCESS.write_text(json.dumps({"status": "COMPLETE_ONE_PASS_CEC_PUBLIC_TEST", "unique_images": 100, "rows": 1800, "input_reads": 300, "gt_reads": 300, "model_parameter_updates": 0, "qualitative_cache_seed": 20260801, "result_sha256": sha(FINAL), "Endo4IE_access": 0, "RLE_new_access": 0}, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": "COMPLETE", "rows": 1800, "sha256": sha(FINAL)}))


if __name__ == "__main__":
    main()
