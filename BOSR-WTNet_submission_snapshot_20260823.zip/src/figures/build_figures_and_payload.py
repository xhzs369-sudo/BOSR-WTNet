from __future__ import annotations

import csv
import json
import math
import os
from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.backends.backend_pdf import PdfPages
from PIL import Image

ROOT = Path(os.environ.get("BOSR_PROJECT_ROOT", Path(__file__).resolve().parents[3]))
SOURCE_ROOT = ROOT / "experiments/innovation_search/ecf_wtnet/bosr_final_public_test_20260814/results"
SOURCE_CSV = SOURCE_ROOT / "PUBLIC_TEST_ALL_GROUPS_PER_IMAGE.csv"
ANALYSIS_JSON = SOURCE_ROOT / "PUBLIC_TEST_ANALYSIS.json"
REGIONAL_JSON = SOURCE_ROOT / "PUBLIC_TEST_REGIONAL_ANALYSIS.json"
CACHE = SOURCE_ROOT / "qualitative_cache"
WORK = Path(__file__).resolve().parent
DESKTOP = Path(os.environ.get("BOSR_FIGURE_OUTPUT", WORK / "generated_figures"))
FIGDIR, SOURCEDIR = DESKTOP / "figures", DESKTOP / "source_data"
SEEDS = (20260801, 20260802, 20260803)
GROUPS = ("WTNet-50", "WTNet-100", "ECF", "BOSR-WTNet", "ECF+BOSR", "GenericHead")
METRICS = ("mse", "psnr_db", "ssim", "delta_e00")
MM_TO_INCH = 1.0 / 25.4
DOUBLE_COLUMN_WIDTH = 183.0 * MM_TO_INCH
SINGLE_COLUMN_WIDTH = 89.0 * MM_TO_INCH

COLORS = {
    "WTNet-50": "#7A7A7A", "WTNet-100": "#A6A6A6", "ECF": "#5B8DB8",
    "BOSR-WTNet": "#D8843F", "ECF+BOSR": "#B69A56", "GenericHead": "#6C9B7D",
}

mpl.rcParams.update({
    "font.family": "sans-serif", "font.sans-serif": ["Arial", "DejaVu Sans", "sans-serif"],
    "svg.fonttype": "none", "pdf.fonttype": 42, "font.size": 7,
    "axes.spines.right": False, "axes.spines.top": False, "axes.linewidth": 0.7,
    "xtick.major.width": 0.7, "ytick.major.width": 0.7, "legend.frameon": False,
})


def read_rows():
    with SOURCE_CSV.open("r", encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def save_figure(fig, stem: str):
    FIGDIR.mkdir(parents=True, exist_ok=True)
    fig.savefig(FIGDIR / f"{stem}.svg", bbox_inches="tight", facecolor="white")
    fig.savefig(FIGDIR / f"{stem}.pdf", bbox_inches="tight", facecolor="white")
    fig.savefig(FIGDIR / f"{stem}.png", dpi=300, bbox_inches="tight", facecolor="white")
    fig.savefig(FIGDIR / f"{stem}.tiff", dpi=600, bbox_inches="tight", facecolor="white")
    plt.close(fig)


def write_csv(path: Path, header, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.writer(stream); writer.writerow(header); writer.writerows(rows)


def main():
    DESKTOP.mkdir(parents=True, exist_ok=True); FIGDIR.mkdir(exist_ok=True); SOURCEDIR.mkdir(exist_ok=True)
    rows = read_rows()
    if len(rows) != 1800:
        raise RuntimeError("Expected all 1800 frozen rows")
    analysis = json.loads(ANALYSIS_JSON.read_text(encoding="utf-8"))
    regional = json.loads(REGIONAL_JSON.read_text(encoding="utf-8"))
    table = {(int(row["seed"]), row["group"], row["filename"]): row for row in rows}
    names = [f"{i}.png" for i in range(100)]

    # Workbook payload and traceable source tables.
    payload = {"raw_rows": rows, "group_summary": analysis["group_summary"], "comparisons": analysis["comparisons"], "regions": regional["regions"], "decision": json.loads((SOURCE_ROOT / "PUBLIC_TEST_DECISION.json").read_text(encoding="utf-8"))}
    (WORK / "workbook_payload.json").write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
    summary_rows = []
    for group in GROUPS:
        for metric in METRICS:
            item = analysis["group_summary"][group][metric]
            summary_rows.append([group, metric, *item["seed_means"], item["three_seed_mean"], item["between_seed_sample_sd"]])
    write_csv(SOURCEDIR / "group_seed_summary.csv", ["group", "metric", "seed_20260801", "seed_20260802", "seed_20260803", "three_seed_mean", "between_seed_sd"], summary_rows)

    # Fig. 1: endpoint summary with all seed means.
    fig, axes = plt.subplots(2, 2, figsize=(DOUBLE_COLUMN_WIDTH, 122.0 * MM_TO_INCH))
    labels = {"mse": "MSE (lower is better)", "psnr_db": "PSNR (dB; higher is better)", "ssim": "SSIM (higher is better)", "delta_e00": r"$\Delta E_{00}$ (lower is better)"}
    for panel, (ax, metric) in enumerate(zip(axes.flat, METRICS)):
        x = np.arange(len(GROUPS))
        for idx, group in enumerate(GROUPS):
            vals = np.asarray(analysis["group_summary"][group][metric]["seed_means"])
            ax.scatter(np.full(3, idx) + np.array([-0.07, 0, 0.07]), vals, s=13, color=COLORS[group], edgecolor="white", linewidth=0.35, zorder=3)
            ax.errorbar(idx, vals.mean(), yerr=vals.std(ddof=1), fmt="_", markersize=10, color="#222222", linewidth=0.8, capsize=2, zorder=4)
        ax.set_xticks(x, GROUPS, rotation=28, ha="right")
        ax.set_ylabel(labels[metric]); ax.grid(axis="y", color="#E8E8E8", linewidth=0.6)
        ax.text(-0.12, 1.05, chr(97 + panel), transform=ax.transAxes, fontweight="bold", fontsize=8)
    fig.suptitle("Public-test performance across three training seeds", fontsize=9, y=1.01)
    fig.tight_layout()
    save_figure(fig, "Figure_1_Public_Test_Performance")

    # Fig. 2: all preregistered comparisons and CIs.
    comparison_order = ["BOSR-WTNet_vs_WTNet-50", "BOSR-WTNet_vs_ECF", "BOSR-WTNet_vs_GenericHead", "ECF+BOSR_vs_BOSR-WTNet", "WTNet-100_vs_WTNet-50"]
    comparison_labels = ["BOSR vs WTNet-50", "BOSR vs ECF", "BOSR vs Generic", "ECF+BOSR vs BOSR", "WTNet-100 vs WTNet-50"]
    fig, axes = plt.subplots(2, 2, figsize=(DOUBLE_COLUMN_WIDTH, 118.0 * MM_TO_INCH))
    source_rows = []
    for panel, (ax, metric) in enumerate(zip(axes.flat, METRICS)):
        points, lows, highs = [], [], []
        for key, label in zip(comparison_order, comparison_labels):
            item = analysis["comparisons"][key][metric]
            if metric in ("mse", "delta_e00"):
                effect = item["relative_improvement"]; point, low, high = effect["relative_improvement_percent"], effect["ci95_low"], effect["ci95_high"]
                xlab = "Relative improvement (%)"
            else:
                effect = item["aggregate_image_bootstrap"]; point, low, high = effect["mean"], effect["ci95_low"], effect["ci95_high"]
                xlab = "Difference (candidate - control)" + (" (dB)" if metric == "psnr_db" else "")
            points.append(point); lows.append(low); highs.append(high); source_rows.append([key, metric, point, low, high])
        y = np.arange(len(points))[::-1]
        ax.axvline(0, color="#555555", linewidth=0.8, linestyle="--")
        ax.errorbar(points, y, xerr=[np.asarray(points) - lows, np.asarray(highs) - points], fmt="o", color="#D8843F", ecolor="#777777", capsize=2, markersize=4)
        ax.set_yticks(y, comparison_labels); ax.set_xlabel(xlab); ax.grid(axis="x", color="#E8E8E8", linewidth=0.6)
        ax.set_title(labels[metric], fontsize=8); ax.text(-0.18, 1.05, chr(97 + panel), transform=ax.transAxes, fontweight="bold", fontsize=8)
    fig.suptitle("Paired image-level effects with 95% bootstrap confidence intervals", fontsize=9, y=1.01)
    fig.tight_layout(); save_figure(fig, "Figure_2_Paired_Effect_Forest")
    write_csv(SOURCEDIR / "comparison_confidence_intervals.csv", ["comparison", "metric", "effect", "ci95_low", "ci95_high"], source_rows)

    # Fig. 3: all n=100 paired effects (positive is favorable for every panel).
    # Horizontal jitter is deterministic and independent of the effect magnitude.
    effect_data = {metric: [] for metric in METRICS}
    for name in names:
        for metric in METRICS:
            bosr = np.mean([float(table[(seed, "BOSR-WTNet", name)][metric]) for seed in SEEDS])
            base = np.mean([float(table[(seed, "WTNet-50", name)][metric]) for seed in SEEDS])
            if metric in ("mse", "delta_e00"):
                effect_data[metric].append((base - bosr) / base * 100)
            else:
                effect_data[metric].append((bosr - base) * (1000 if metric == "ssim" else 1))
    fig, axes = plt.subplots(2, 2, figsize=(DOUBLE_COLUMN_WIDTH, 115.0 * MM_TO_INCH))
    per_image_rows = []
    units = {"mse": "MSE improvement (%)", "psnr_db": "PSNR difference (dB)", "ssim": r"SSIM difference ($\times 10^3$)", "delta_e00": r"$\Delta E_{00}$ improvement (%)"}
    for panel, (ax, metric) in enumerate(zip(axes.flat, METRICS)):
        values = np.asarray(effect_data[metric])
        # Fixed low-discrepancy x offsets keyed only to filename order; no
        # effect-dependent ordering and no random/simulated observations.
        jitter = 0.065 * np.sin((np.arange(len(values), dtype=np.float64) + 1.0) * 2.399963229728653)
        ax.scatter(jitter, values, s=10, alpha=0.55, color="#D8843F", edgecolor="none")
        ax.boxplot(values, positions=[0], widths=0.25, showfliers=False, patch_artist=True, boxprops={"facecolor": "none", "edgecolor": "#333333"}, medianprops={"color": "#333333"}, whiskerprops={"color": "#333333"}, capprops={"color": "#333333"})
        ax.axhline(0, color="#555555", linestyle="--", linewidth=0.8); ax.set_xlim(-0.22, 0.22); ax.set_xticks([]); ax.set_ylabel(units[metric]); ax.grid(axis="y", color="#E8E8E8", linewidth=0.6)
        ax.text(-0.12, 1.05, chr(97 + panel), transform=ax.transAxes, fontweight="bold", fontsize=8)
        for name, value in zip(names, values): per_image_rows.append([name, metric, value])
    fig.suptitle("Complete paired public-test effects: BOSR-WTNet versus WTNet-50 (n = 100 images)", fontsize=9, y=1.01)
    fig.tight_layout(); save_figure(fig, "Figure_3_Per_Image_Effect_Distributions")
    write_csv(SOURCEDIR / "per_image_primary_effects.csv", ["filename", "metric", "favorable_effect"], per_image_rows)

    # Supplementary Fig. 1: GT-luminance-bin MAE differences. These bins are
    # intensity strata only and must not be interpreted as tissue/anatomy ROIs.
    regions = ("dark", "normal", "highlight")
    points, lows, highs, rels = [], [], [], []
    for region in regions:
        item = regional["regions"][region]; stat = item["absolute_difference_bootstrap"]
        points.append(stat["mean"]); lows.append(stat["ci95_low"]); highs.append(stat["ci95_high"]); rels.append(item["relative_improvement_percent_descriptive"])
    fig, ax = plt.subplots(figsize=(SINGLE_COLUMN_WIDTH, 72.0 * MM_TO_INCH))
    y = np.arange(3)[::-1]; ax.axvline(0, color="#555555", linestyle="--", linewidth=0.8)
    ax.errorbar(points, y, xerr=[np.asarray(points)-lows, np.asarray(highs)-points], fmt="o", color="#D8843F", ecolor="#777777", capsize=2, markersize=4)
    ax.set_yticks(y, ["Low-GT-luminance pixels (n=100)", "Mid-GT-luminance pixels (n=100)", "High-GT-luminance pixels (n=78)"]); ax.set_xlabel("Luminance MAE difference\n(BOSR-WTNet - WTNet-50)")
    ax.grid(axis="x", color="#E8E8E8", linewidth=0.6)
    for yy, high, rel in zip(y, highs, rels): ax.text(high + max(abs(np.asarray(highs)-np.asarray(lows))) * 0.04, yy, f"{rel:+.1f}%", va="center", fontsize=6)
    ax.set_title("GT-luminance-bin error effects", fontsize=8); fig.tight_layout(); save_figure(fig, "Supplementary_Figure_1_GT_Luminance_Bins")

    # Fig. 5: disclosed worst / median / best cases by aggregate MSE improvement.
    mse_effect = np.asarray(effect_data["mse"]); order = np.argsort(mse_effect)
    chosen = [("Worst", names[order[0]], mse_effect[order[0]]), ("Median", names[order[len(order)//2]], mse_effect[order[len(order)//2]]), ("Best", names[order[-1]], mse_effect[order[-1]])]
    (SOURCEDIR / "qualitative_selection_rule.json").write_text(json.dumps({"rule": "minimum, median and maximum aggregate three-seed per-image MSE improvement", "selected": [{"label": label, "filename": name, "mse_improvement_percent": float(value)} for label, name, value in chosen]}, indent=2), encoding="utf-8")
    columns = ("input", "WTNet-50", "ECF", "BOSR-WTNet", "gt")
    fig, axes = plt.subplots(3, 5, figsize=(DOUBLE_COLUMN_WIDTH, 111.0 * MM_TO_INCH))
    for row_idx, (case, name, effect) in enumerate(chosen):
        for col_idx, group in enumerate(columns):
            image = np.asarray(Image.open(CACHE / group / name).convert("RGB"))
            axes[row_idx, col_idx].imshow(image); axes[row_idx, col_idx].axis("off")
            if row_idx == 0: axes[row_idx, col_idx].set_title(group, fontsize=7)
            if col_idx == 0: axes[row_idx, col_idx].text(-0.04, 0.5, f"{case}\n{effect:+.1f}%", transform=axes[row_idx, col_idx].transAxes, ha="right", va="center", fontsize=6)
    fig.suptitle("Disclosed worst, median and best cases by paired MSE improvement", fontsize=9, y=0.995)
    fig.tight_layout(pad=0.5); save_figure(fig, "Figure_4_Qualitative_Comparison")

    # Complete 100-image supplement, ten pages, fixed filename order.
    with PdfPages(FIGDIR / "Supplement_All_100_Public_Test_Images.pdf") as pdf:
        for page in range(10):
            page_names = names[page*10:(page+1)*10]
            fig, axes = plt.subplots(10, 4, figsize=(DOUBLE_COLUMN_WIDTH, 235.0 * MM_TO_INCH))
            for r, name in enumerate(page_names):
                for c, group in enumerate(("input", "WTNet-50", "BOSR-WTNet", "gt")):
                    axes[r, c].imshow(np.asarray(Image.open(CACHE / group / name).convert("RGB"))); axes[r, c].axis("off")
                    if r == 0: axes[r, c].set_title(group, fontsize=6)
                    if c == 0: axes[r, c].text(-0.04, 0.5, name, transform=axes[r, c].transAxes, ha="right", va="center", fontsize=5)
            fig.suptitle(f"Complete public-test qualitative comparison (page {page+1}/10)", fontsize=8)
            fig.tight_layout(pad=0.25); pdf.savefig(fig, bbox_inches="tight");
            if page == 0: fig.savefig(FIGDIR / "Supplement_All100_Page1_Preview.png", dpi=300, bbox_inches="tight")
            plt.close(fig)

    legends = """# Figure legends\n\n**Fig. 1 | Public-test performance across three training seeds.** Points show per-seed means over the same 100 paired CEC public-test images; horizontal markers and error bars denote the three-seed mean and between-seed sample SD. Lower values are favorable for MSE and DeltaE00; higher values are favorable for PSNR and SSIM.\n\n**Fig. 2 | Paired image-level effects with uncertainty.** Candidate-minus-control effects are shown for PSNR and SSIM; MSE and DeltaE00 are expressed as relative improvement. Points denote effects after averaging the three seed-specific effects within each image; error bars are paired image-level percentile 95% confidence intervals from 10,000 bootstrap resamples (n = 100 images; seed 20260814).\n\n**Fig. 3 | Complete paired effects of BOSR-WTNet versus WTNet-50.** Every public-test image is shown once after averaging three training-seed effects within image (n = 100). Positive values favor BOSR-WTNet. Boxes show medians and interquartile ranges; whiskers extend to 1.5 times the interquartile range. Points use deterministic horizontal jitter independent of effect magnitude and have no ordered x-axis meaning.\n\n**Fig. 4 | Qualitative comparison under a disclosed selection rule.** Cases are the minimum, median and maximum aggregate three-seed per-image MSE improvements among all 100 public-test images. Images are lossless cached outputs from the one-pass evaluation; no crop or local image adjustment was applied. The complete 100-image comparison is supplied separately.\n\n**Supplementary Fig. 1 | GT-luminance-bin error effects.** Points show BOSR-WTNet minus WTNet-50 luminance MAE; negative values favor BOSR-WTNet. Error bars are paired image-level percentile 95% confidence intervals from 10,000 bootstrap resamples. Low- and mid-GT-luminance bins were computable in 100 images; the high-GT-luminance bin was computable in 78 images. Percentage labels are descriptive relative improvements. Bins are defined only by GT pixel luminance and are not tissue, anatomical or lesion regions; pixels outside the endoscopic field of view may contribute to the low-luminance bin.\n\nSource data are provided in the accompanying workbook and CSV files.\n"""
    (DESKTOP / "Figure_Legends.md").write_text(legends, encoding="utf-8")
    qa = {"source_rows": len(rows), "unique_images": len(names), "groups": list(GROUPS), "seeds": list(SEEDS), "excluded_rows": 0, "public_test_image_rereads": 0, "figure3_jitter": "deterministic low-discrepancy x offsets based only on fixed filename order; independent of effect magnitude", "supplementary_luminance_bins": "GT intensity strata only; not tissue/anatomy/lesion ROIs; low bin may include out-of-FOV background", "qualitative_rule": "worst/median/best by aggregate MSE improvement; all 100 also supplied", "backend": "Python/matplotlib", "claim_boundary": "MSE and PSNR are directional; SSIM and DeltaE00 have favorable CIs; no SOTA or clinical-region claim."}
    (DESKTOP / "FIGURE_QA_NOTES.json").write_text(json.dumps(qa, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"status": "FIGURES_AND_PAYLOAD_COMPLETE", "output": str(DESKTOP), "rows": len(rows)}))


if __name__ == "__main__":
    main()
