# Figure contract

Core conclusion: BOSR-WTNet provides independently supported gains in SSIM and DeltaE00 over WTNet-50, while MSE and PSNR improve directionally with uncertainty intervals crossing zero.

Figure archetype: quantitative grid plus image plate.

Target output: SCI journal, 183 mm double-column figures, editable SVG/PDF plus 600-dpi TIFF and PNG previews.

Backend: Python/matplotlib only.

Panel map:
- Figure 1: six-group three-seed performance summary across four endpoints.
- Figure 2: paired image-level confidence intervals for all preregistered comparisons.
- Figure 3: complete n=100 paired-effect distributions for BOSR-WTNet versus WTNet-50.
- Figure 4: dark, normal and highlight regional luminance-error differences.
- Figure 5: worst, median and best cases under a disclosed MSE-improvement ranking rule.
- Supplement: all 100 public-test images, with no result-based exclusion.

Evidence hierarchy:
- Hero evidence: public-test paired effects and 95% CIs.
- Validation: per-image distributions and three-seed group summaries.
- Controls: ECF, ECF+BOSR, WTNet-100 and GenericHead.

Statistics: n=100 paired test images; three training seeds are averaged within image; 10,000 paired image-level percentile bootstrap resamples; seed 20260814.

Image integrity: lossless cached PNGs from the one-pass public-test evaluation; no local contrast, gamma, crop or selective image exclusion.

Reviewer risk: MSE and PSNR CIs cross zero; BOSR-WTNet is slightly weaker than GenericHead; figures must not imply universal or SOTA superiority.
