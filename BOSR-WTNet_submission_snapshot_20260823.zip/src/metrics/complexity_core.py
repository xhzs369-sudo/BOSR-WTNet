"""Transparent parameter, Conv/Linear MAC, latency and CUDA-memory measurements."""

from __future__ import annotations

import time
from typing import Dict

import numpy as np
import torch
from torch import nn


def count_parameters(model: nn.Module) -> Dict[str, int]:
    return {
        "parameters_total": int(sum(p.numel() for p in model.parameters())),
        "parameters_trainable": int(sum(p.numel() for p in model.parameters() if p.requires_grad)),
    }


def count_conv_linear_macs(model: nn.Module, example_input: torch.Tensor) -> Dict[str, int | str]:
    macs = 0
    handles = []

    def conv_hook(module: nn.Conv2d, _inputs, output):
        nonlocal macs
        output_elements = int(output.numel())
        kernel_per_output = int(module.kernel_size[0] * module.kernel_size[1] * module.in_channels / module.groups)
        macs += output_elements * kernel_per_output

    def linear_hook(module: nn.Linear, _inputs, output):
        nonlocal macs
        macs += int(output.numel()) * int(module.in_features)

    for module in model.modules():
        if isinstance(module, nn.Conv2d):
            handles.append(module.register_forward_hook(conv_hook))
        elif isinstance(module, nn.Linear):
            handles.append(module.register_forward_hook(linear_hook))
    try:
        with torch.inference_mode():
            model(example_input)
    finally:
        for handle in handles:
            handle.remove()
    return {
        "counted_macs": int(macs),
        "counted_flops_2_per_mac": int(2 * macs),
        "scope": "nn.Conv2d and nn.Linear only; DWT/IDWT and elementwise operations excluded",
    }


def benchmark_latency(
    model: nn.Module,
    example_input: torch.Tensor,
    warmup: int = 50,
    repeats: int = 200,
) -> Dict[str, float | int | str]:
    if not example_input.is_cuda:
        raise ValueError("Formal latency benchmarking requires a CUDA input")
    if tuple(example_input.shape) != (1, 3, 420, 420):
        raise ValueError(f"Frozen latency input must be [1,3,420,420], got {tuple(example_input.shape)}")
    if warmup < 0 or repeats < 2:
        raise ValueError("warmup must be nonnegative and repeats must be at least 2")
    model.eval()
    with torch.inference_mode():
        for _ in range(warmup):
            model(example_input)
        torch.cuda.synchronize(example_input.device)
        torch.cuda.reset_peak_memory_stats(example_input.device)
        elapsed_ms = np.empty(repeats, dtype=np.float64)
        for index in range(repeats):
            torch.cuda.synchronize(example_input.device)
            start = time.perf_counter_ns()
            model(example_input)
            torch.cuda.synchronize(example_input.device)
            elapsed_ms[index] = (time.perf_counter_ns() - start) / 1_000_000.0
    return {
        "warmup": int(warmup),
        "repeats": int(repeats),
        "mean_ms": float(elapsed_ms.mean()),
        "sample_sd_ms": float(elapsed_ms.std(ddof=1)),
        "median_ms": float(np.median(elapsed_ms)),
        "p95_ms": float(np.percentile(elapsed_ms, 95.0)),
        "fps_from_mean": float(1000.0 / elapsed_ms.mean()),
        "peak_allocated_bytes": int(torch.cuda.max_memory_allocated(example_input.device)),
        "peak_reserved_bytes": int(torch.cuda.max_memory_reserved(example_input.device)),
        "input_shape": list(example_input.shape),
        "io_timing": "excluded",
    }
