"""Paired image-level inference and frozen success rules."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Iterable

import numpy as np
from scipy.stats import wilcoxon


BOOTSTRAP_RESAMPLES = 10_000
BOOTSTRAP_SEED = 20_260_810
SSIM_NONINFERIORITY_MARGIN = -0.001


def _finite_1d(values: Iterable[float], name: str) -> np.ndarray:
    array = np.asarray(list(values), dtype=np.float64)
    if array.ndim != 1 or array.size == 0:
        raise ValueError(f"{name} must be a non-empty one-dimensional array")
    if not np.isfinite(array).all():
        raise ValueError(f"{name} contains non-finite values")
    return array


def paired_percentile_bootstrap(
    paired_differences: Iterable[float],
    resamples: int = BOOTSTRAP_RESAMPLES,
    seed: int = BOOTSTRAP_SEED,
) -> Dict[str, float]:
    diffs = _finite_1d(paired_differences, "paired_differences")
    if resamples <= 0:
        raise ValueError("resamples must be positive")
    rng = np.random.default_rng(seed)
    means = np.empty(resamples, dtype=np.float64)
    # Chunking avoids allocating resamples x N for larger future datasets.
    chunk = 1000
    for start in range(0, resamples, chunk):
        stop = min(start + chunk, resamples)
        indices = rng.integers(0, diffs.size, size=(stop - start, diffs.size))
        means[start:stop] = diffs[indices].mean(axis=1)
    low, high = np.percentile(means, [2.5, 97.5])
    return {
        "n": int(diffs.size),
        "mean": float(diffs.mean()),
        "sample_sd": float(diffs.std(ddof=1)) if diffs.size > 1 else float("nan"),
        "ci95_low": float(low),
        "ci95_high": float(high),
        "resamples": int(resamples),
        "seed": int(seed),
    }


def favorable_proportion(differences: Iterable[float], higher_is_better: bool) -> float:
    diffs = _finite_1d(differences, "differences")
    favorable = diffs > 0.0 if higher_is_better else diffs < 0.0
    return float(np.mean(favorable))


def aggregate_three_seed_by_image(seed_by_image: np.ndarray) -> np.ndarray:
    array = np.asarray(seed_by_image, dtype=np.float64)
    if array.ndim != 2 or array.shape[0] != 3:
        raise ValueError("Expected shape [3 seeds, N images]")
    if array.shape[1] == 0 or not np.isfinite(array).all():
        raise ValueError("Three-seed table must be non-empty and finite")
    return array.mean(axis=0)


def evaluate_joint_success(psnr: np.ndarray, delta_e00: np.ndarray, ssim: np.ndarray) -> dict:
    tables = {"psnr": np.asarray(psnr, dtype=np.float64), "delta_e00": np.asarray(delta_e00, dtype=np.float64), "ssim": np.asarray(ssim, dtype=np.float64)}
    shape = tables["psnr"].shape
    if len(shape) != 2 or shape[0] != 3 or shape[1] == 0:
        raise ValueError("Each endpoint must have shape [3 seeds, N images]")
    if any(v.shape != shape or not np.isfinite(v).all() for v in tables.values()):
        raise ValueError("Endpoint tables must share one finite complete shape")

    seed_means = {name: values.mean(axis=1) for name, values in tables.items()}
    aggregate = {name: aggregate_three_seed_by_image(values) for name, values in tables.items()}
    ci = {name: paired_percentile_bootstrap(values) for name, values in aggregate.items()}
    checks = {
        "psnr_each_seed_positive": bool(np.all(seed_means["psnr"] > 0.0)),
        "psnr_ci_lower_positive": bool(ci["psnr"]["ci95_low"] > 0.0),
        "delta_e_each_seed_negative": bool(np.all(seed_means["delta_e00"] < 0.0)),
        "delta_e_ci_upper_negative": bool(ci["delta_e00"]["ci95_high"] < 0.0),
        "ssim_each_seed_noninferior": bool(np.all(seed_means["ssim"] >= SSIM_NONINFERIORITY_MARGIN)),
        "ssim_ci_lower_noninferior": bool(ci["ssim"]["ci95_low"] >= SSIM_NONINFERIORITY_MARGIN),
    }
    return {
        "passed": bool(all(checks.values())),
        "checks": checks,
        "seed_means": {k: v.tolist() for k, v in seed_means.items()},
        "aggregate_bootstrap": ci,
        "ssim_margin": SSIM_NONINFERIORITY_MARGIN,
    }


def holm_adjust(raw_p_values: Iterable[float]) -> np.ndarray:
    p = _finite_1d(raw_p_values, "raw_p_values")
    if np.any((p < 0.0) | (p > 1.0)):
        raise ValueError("p values must be inside [0,1]")
    order = np.argsort(p)
    adjusted_sorted = np.maximum.accumulate((p.size - np.arange(p.size)) * p[order])
    adjusted_sorted = np.minimum(adjusted_sorted, 1.0)
    adjusted = np.empty_like(adjusted_sorted)
    adjusted[order] = adjusted_sorted
    return adjusted


def paired_wilcoxon(candidate: Iterable[float], reference: Iterable[float]) -> float:
    candidate_array = _finite_1d(candidate, "candidate")
    reference_array = _finite_1d(reference, "reference")
    if candidate_array.shape != reference_array.shape:
        raise ValueError("candidate and reference must be paired with equal length")
    differences = candidate_array - reference_array
    if np.all(differences == 0.0):
        return 1.0
    return float(wilcoxon(differences, zero_method="wilcox", correction=False, alternative="two-sided", method="auto").pvalue)


def summarize_seed(differences: Iterable[float], higher_is_better: bool) -> dict:
    diffs = _finite_1d(differences, "differences")
    summary = paired_percentile_bootstrap(diffs)
    summary["favorable_proportion"] = favorable_proportion(diffs, higher_is_better)
    return summary


def psnr_percent_change(*_args, **_kwargs):
    raise RuntimeError("PSNR is measured in dB; percentage change of dB values is forbidden")
