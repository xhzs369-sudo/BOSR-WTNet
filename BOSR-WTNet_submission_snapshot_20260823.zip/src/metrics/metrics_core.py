"""Frozen full-reference image-quality metrics for the ECF-WTNet paper protocol."""

from __future__ import annotations

import hashlib
import os
import sys
from pathlib import Path
from typing import Dict

import numpy as np
import skimage
from skimage.color import deltaE_ciede2000, rgb2lab


WTNET_ROOT = Path(
    os.environ.get("WTNET_ROOT", Path(__file__).resolve().parents[1] / "wtnet")
)
BASICSR_METRIC = WTNET_ROOT / "basicsr" / "metrics" / "psnr_ssim.py"
BASICSR_METRIC_SHA256 = "ac5cc62870d702fecae1558729215d7f980bb12a960d90ecb950311c5489e6b7"
EXPECTED_SKIMAGE_VERSION = "0.24.0"
MIN_REGION_PIXELS = 64


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def verify_metric_dependencies() -> None:
    if sha256_file(BASICSR_METRIC) != BASICSR_METRIC_SHA256:
        raise RuntimeError("Frozen BasicSR metric implementation hash mismatch")
    if skimage.__version__ != EXPECTED_SKIMAGE_VERSION:
        raise RuntimeError(
            f"scikit-image version mismatch: {skimage.__version__} != {EXPECTED_SKIMAGE_VERSION}"
        )


verify_metric_dependencies()
if str(WTNET_ROOT) not in sys.path:
    sys.path.insert(0, str(WTNET_ROOT))
from basicsr.metrics.psnr_ssim import calculate_psnr, calculate_ssim  # noqa: E402

_imported_metric_path = Path(sys.modules[calculate_psnr.__module__].__file__).resolve()
if _imported_metric_path != BASICSR_METRIC.resolve():
    raise RuntimeError(f"Unexpected BasicSR metric module imported: {_imported_metric_path}")


def validate_rgb_pair(prediction: np.ndarray, target: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    pred = np.asarray(prediction)
    gt = np.asarray(target)
    if pred.shape != gt.shape:
        raise ValueError(f"Shape mismatch: prediction={pred.shape}, target={gt.shape}")
    if pred.ndim != 3 or pred.shape[2] != 3:
        raise ValueError(f"Expected HWC RGB arrays, got {pred.shape}")
    if not np.issubdtype(pred.dtype, np.floating) or not np.issubdtype(gt.dtype, np.floating):
        raise TypeError("Prediction and target must use floating-point dtypes")
    if not np.isfinite(pred).all() or not np.isfinite(gt).all():
        raise ValueError("Prediction and target must contain only finite values")
    if pred.min() < 0.0 or pred.max() > 1.0 or gt.min() < 0.0 or gt.max() > 1.0:
        raise ValueError("Prediction and target must be inside [0,1]")
    return pred.astype(np.float64, copy=False), gt.astype(np.float64, copy=False)


def calculate_full_reference_metrics(prediction: np.ndarray, target: np.ndarray) -> Dict[str, float]:
    pred, gt = validate_rgb_pair(prediction, target)
    mse = float(np.mean(np.square(pred - gt), dtype=np.float64))
    psnr = float(calculate_psnr(pred, gt, crop_border=0, input_order="HWC", test_y_channel=False))
    ssim = float(calculate_ssim(pred, gt, crop_border=0, input_order="HWC", test_y_channel=False))
    delta_e = deltaE_ciede2000(rgb2lab(pred), rgb2lab(gt))
    return {
        "mse": mse,
        "psnr_db": psnr,
        "ssim": ssim,
        "delta_e00": float(np.mean(delta_e, dtype=np.float64)),
    }


def bt601_luminance(rgb: np.ndarray) -> np.ndarray:
    array = np.asarray(rgb, dtype=np.float64)
    return 0.299 * array[..., 0] + 0.587 * array[..., 1] + 0.114 * array[..., 2]


def calculate_region_luminance_metrics(prediction: np.ndarray, target: np.ndarray) -> Dict[str, dict]:
    pred, gt = validate_rgb_pair(prediction, target)
    pred_y, gt_y = bt601_luminance(pred), bt601_luminance(gt)
    masks = {
        "dark": gt_y < 0.25,
        "normal": (gt_y >= 0.25) & (gt_y < 0.75),
        "highlight": gt_y >= 0.75,
    }
    output: Dict[str, dict] = {}
    absolute_error = np.abs(pred_y - gt_y)
    for name, mask in masks.items():
        count = int(mask.sum())
        computable = count >= MIN_REGION_PIXELS
        output[name] = {
            "pixel_count": count,
            "computable": computable,
            "luminance_mae": float(np.mean(absolute_error[mask], dtype=np.float64)) if computable else float("nan"),
        }
    return output


def paired_region_change(candidate: dict, control: dict) -> Dict[str, dict]:
    output: Dict[str, dict] = {}
    for region in ("dark", "normal", "highlight"):
        cnd, ctl = candidate[region], control[region]
        valid = bool(cnd["computable"] and ctl["computable"])
        if not valid:
            output[region] = {"computable": False, "absolute_change": float("nan"), "relative_change_percent": float("nan")}
            continue
        absolute = float(cnd["luminance_mae"] - ctl["luminance_mae"])
        baseline = float(ctl["luminance_mae"])
        relative = float(100.0 * absolute / baseline) if baseline != 0.0 else float("nan")
        output[region] = {"computable": True, "absolute_change": absolute, "relative_change_percent": relative}
    return output


def calculate_lpips_alex(prediction: np.ndarray, target: np.ndarray, model, device: str) -> float:
    """Exploratory LPIPS; caller owns one frozen eval-mode model instance."""
    import torch

    pred, gt = validate_rgb_pair(prediction, target)
    pred_t = torch.from_numpy(pred.transpose(2, 0, 1)).unsqueeze(0).float().to(device)
    gt_t = torch.from_numpy(gt.transpose(2, 0, 1)).unsqueeze(0).float().to(device)
    with torch.inference_mode():
        value = model(2.0 * pred_t - 1.0, 2.0 * gt_t - 1.0, normalize=False)
    return float(value.detach().cpu().reshape(-1)[0])


def build_frozen_lpips_alex(device: str):
    """Build the exploratory LPIPS model only after verifying both frozen weight files."""
    import lpips
    import torch

    lpips_root = Path(lpips.__file__).resolve().parent
    linear_weight = lpips_root / "weights" / "v0.1" / "alex.pth"
    backbone = Path(torch.hub.get_dir()) / "checkpoints" / "alexnet-owt-7be5be79.pth"
    expected = {
        linear_weight: "df73285e35b22355a2df87cdb6b70b343713b667eddbda73e1977e0c860835c0",
        backbone: "7be5be791159472b1fbf3c69796f7cb30dca7ad8466c2df70058c37116cdee02",
    }
    for path, digest in expected.items():
        if not path.is_file() or sha256_file(path) != digest:
            raise RuntimeError(f"Frozen LPIPS dependency missing or changed: {path}")
    model = lpips.LPIPS(net="alex", version="0.1", lpips=True, pretrained=True, eval_mode=True, verbose=False)
    model = model.to(device).eval()
    for parameter in model.parameters():
        parameter.requires_grad_(False)
    return model
