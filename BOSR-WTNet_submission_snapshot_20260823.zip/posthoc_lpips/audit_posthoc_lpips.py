"""Independent structural and numerical audit of post hoc exploratory LPIPS artifacts."""
from __future__ import annotations

import csv
import hashlib
import json
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
PUBLIC = HERE.parent
CSV_PATH = HERE / "POSTHOC_LPIPS_PER_IMAGE.csv"
ANALYSIS_PATH = HERE / "POSTHOC_LPIPS_ANALYSIS.json"
ACCESS_PATH = HERE / "POSTHOC_ACCESS.json"
REPORT_PATH = HERE / "POSTHOC_LPIPS_REPORT_ZH.md"
ARCHIVE_PATH = PUBLIC / "PUBLIC_TEST_FINAL_ARCHIVE_HASHES.json"
OUT = HERE / "INDEPENDENT_AUDIT.json"
GROUPS = ("WTNet-50", "WTNet-100", "GenericHead", "ECF", "BOSR-WTNet", "ECF+BOSR")
SEEDS = (20260801, 20260802, 20260803)


def sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main() -> None:
    with CSV_PATH.open("r", encoding="utf-8-sig", newline="") as stream:
        rows = list(csv.DictReader(stream))
    keys = {(int(row["seed"]), row["group"], row["filename"]) for row in rows}
    values = np.array([float(row["lpips_alex_v01"]) for row in rows], dtype=np.float64)
    expected = {(seed, group, f"{index}.png") for seed in SEEDS for group in GROUPS for index in range(100)}
    analysis = json.loads(ANALYSIS_PATH.read_text(encoding="utf-8"))
    access = json.loads(ACCESS_PATH.read_text(encoding="utf-8"))
    report = REPORT_PATH.read_text(encoding="utf-8")
    table = {(int(row["seed"]), row["group"], row["filename"]): float(row["lpips_alex_v01"]) for row in rows}
    candidate = np.array([np.mean([table[(seed, "BOSR-WTNet", f"{index}.png")] for seed in SEEDS]) for index in range(100)])
    control = np.array([np.mean([table[(seed, "WTNet-50", f"{index}.png")] for seed in SEEDS]) for index in range(100)])
    effect = float(np.mean(candidate - control))
    relative = float(100.0 * (control.mean() - candidate.mean()) / control.mean())
    primary = analysis["comparisons"]["BOSR-WTNet_vs_WTNet-50"]

    archive = json.loads(ARCHIVE_PATH.read_text(encoding="utf-8"))
    archive_ok = True
    for item in archive["files"]:
        path = Path(item["path"])
        archive_ok = archive_ok and path.is_file() and sha(path) == item["sha256"]
    checks = {
        "rows_exactly_1800": len(rows) == 1800,
        "key_set_exact": keys == expected,
        "all_lpips_finite": bool(np.isfinite(values).all()),
        "all_lpips_nonnegative": bool((values >= 0).all()),
        "analysis_unit_100_images": analysis.get("independent_unit") == "100 paired images",
        "seed_values_not_independent_n": analysis.get("seed_values_are_not_independent_n") is True,
        "primary_effect_recomputed": abs(effect - primary["candidate_minus_control"]) < 1e-15,
        "primary_relative_recomputed": abs(relative - primary["ratio_of_means_relative_improvement_percent"]) < 1e-12,
        "posthoc_label_in_report": "事后探索性分析" in report and "post hoc exploratory analysis" in report,
        "no_parameter_updates": access.get("model_parameter_updates") == 0,
        "no_model_selection_changes": access.get("model_selection_changes") == 0,
        "original_decision_not_modified": access.get("original_public_test_decision_modified") is False,
        "original_archive_hashes_intact": archive_ok,
    }
    result = {
        "status": "PASS_INDEPENDENT_POSTHOC_LPIPS_AUDIT" if all(checks.values()) else "FAIL_INDEPENDENT_POSTHOC_LPIPS_AUDIT",
        "checks": checks,
        "recomputed_primary": {
            "candidate_minus_control": effect,
            "relative_improvement_percent": relative,
            "images_candidate_lower": int(np.sum(candidate < control)),
        },
        "interpretation": "POST_HOC_EXPLORATORY_ONLY_DOES_NOT_CHANGE_ORIGINAL_DECISION",
    }
    OUT.write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    if not all(checks.values()):
        raise RuntimeError(json.dumps(checks))
    print(json.dumps(result, ensure_ascii=False))


if __name__ == "__main__":
    main()
