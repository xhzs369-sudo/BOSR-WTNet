"""Post hoc exploratory LPIPS evaluation; never changes the frozen public-test decision."""
from __future__ import annotations

import csv
import hashlib
import json
import os
import sys
from pathlib import Path

import cv2
import numpy as np
import torch
import torch.nn.functional as F

HERE = Path(__file__).resolve().parent
PUBLIC = HERE.parent
ROOT = Path(os.environ.get("BOSR_PROJECT_ROOT", Path(__file__).resolve().parents[1]))
INPUT = ROOT / "datasets/CEC/test/input_under"
GT = ROOT / "datasets/CEC/test/gt"
LOCK = PUBLIC / "PUBLIC_TEST_PRESTART_LOCK.json"
ARCHIVE = PUBLIC / "PUBLIC_TEST_FINAL_ARCHIVE_HASHES.json"
PROTOCOL = HERE / "PREREGISTRATION.json"
PRELOCK = HERE / "PRE_RUN_LOCK.json"
RESULT_CSV = HERE / "POSTHOC_LPIPS_PER_IMAGE.csv"
ANALYSIS_JSON = HERE / "POSTHOC_LPIPS_ANALYSIS.json"
REPORT = HERE / "POSTHOC_LPIPS_REPORT_ZH.md"
ACCESS = HERE / "POSTHOC_ACCESS.json"
HASHES = HERE / "FINAL_ARTIFACT_HASHES.json"

SEEDS = (20260801, 20260802, 20260803)
GROUPS = ("WTNet-50", "WTNet-100", "GenericHead", "ECF", "BOSR-WTNet", "ECF+BOSR")
WEIGHT_GROUP = {
    "WTNet-50": "WTNET-50",
    "WTNet-100": "WTNET-100",
    "GenericHead": "WTNET-GENERIC",
    "ECF": "ECF-FULL",
    "BOSR-WTNet": "BOSR-ONLY",
    "ECF+BOSR": "ECF+BOSR",
}
COMPARISONS = (
    ("BOSR-WTNet", "WTNet-50"),
    ("BOSR-WTNet", "ECF"),
    ("BOSR-WTNet", "GenericHead"),
    ("ECF+BOSR", "BOSR-WTNet"),
    ("WTNet-100", "WTNet-50"),
)

sys.path[:0] = [
    str(ROOT / "experiments/innovation_search/ecf_wtnet/formal_bosr_three_seed_20260814"),
    str(ROOT / "experiments/innovation_search/ecf_wtnet/paper_final_protocol_20260810/implementation"),
    str(ROOT / "experiments/innovation_search/ecf_wtnet/paper_final_protocol_20260810/metric_statistics"),
    str(ROOT / "experiments/innovation_search/ecf_wtnet/advisor_confirmation_single_seed"),
]
from formal_bosr_head import FormalBOSRHead  # noqa: E402
from formal_heads import build_head  # noqa: E402
from ecf_common import CaptureCalibration, load_wtnet  # noqa: E402
from metrics_core import build_frozen_lpips_alex  # noqa: E402


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def verify_original_archive() -> dict[str, str]:
    archive = json.loads(ARCHIVE.read_text(encoding="utf-8"))
    if archive.get("status") != "CEC_PUBLIC_TEST_FINAL_ARCHIVE_FROZEN":
        raise RuntimeError("unexpected original archive status")
    verified = {}
    for item in archive["files"]:
        path = Path(item["path"])
        actual = sha256_file(path)
        if not path.is_file() or actual != item["sha256"]:
            raise RuntimeError(f"original public-test artifact changed: {path}")
        verified[str(path)] = actual
    return verified


def read_rgb(path: Path) -> np.ndarray:
    bgr = cv2.imdecode(np.fromfile(str(path), dtype=np.uint8), cv2.IMREAD_COLOR)
    if bgr is None:
        raise RuntimeError(f"unreadable image: {path}")
    return cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB).astype(np.float32) / 255.0


def infer(model, image: torch.Tensor) -> torch.Tensor:
    height, width = image.shape[-2:]
    pad_h, pad_w = (-height) % 8, (-width) % 8
    padded = F.pad(image, (0, pad_w, 0, pad_h), mode="reflect") if pad_h or pad_w else image
    return model(padded)[..., :height, :width]


def get_weight(lock: dict, seed: int, group: str) -> Path:
    expected_group = WEIGHT_GROUP[group]
    matches = [Path(item["path"]) for item in lock["weights"] if item["seed"] == seed and item["group"] == expected_group]
    if len(matches) != 1:
        raise RuntimeError(f"weight identity failure: seed={seed}, group={group}")
    return matches[0]


def load_models(lock: dict, seed: int, device: torch.device):
    parent50 = load_wtnet(device, get_weight(lock, seed, "WTNet-50")).eval()
    parent100 = load_wtnet(device, get_weight(lock, seed, "WTNet-100")).eval()
    capture = CaptureCalibration(parent50)
    generic = build_head("WTNET-GENERIC").to(device).eval()
    ecf = build_head("ECF-FULL").to(device).eval()
    generic.load_state_dict(torch.load(get_weight(lock, seed, "GenericHead"), map_location="cpu", weights_only=False)["params"], strict=True)
    ecf.load_state_dict(torch.load(get_weight(lock, seed, "ECF"), map_location="cpu", weights_only=False)["params"], strict=True)
    bosr = FormalBOSRHead("BOSR-ONLY").to(device).eval()
    combo = FormalBOSRHead("ECF+BOSR").to(device).eval()
    bosr.load_state_dict(torch.load(get_weight(lock, seed, "BOSR-WTNet"), map_location="cpu", weights_only=False)["params"], strict=True)
    combo.load_state_dict(torch.load(get_weight(lock, seed, "ECF+BOSR"), map_location="cpu", weights_only=False)["params"], strict=True)
    return parent50, parent100, capture, generic, ecf, bosr, combo


def lpips_value(model, prediction: torch.Tensor, target: torch.Tensor) -> float:
    pred = torch.clamp(prediction, 0, 1)
    gt = torch.clamp(target, 0, 1)
    return float(model(2.0 * pred - 1.0, 2.0 * gt - 1.0, normalize=False).reshape(-1)[0].detach().cpu())


def percentile_ci(values: np.ndarray, rng: np.random.Generator, statistic) -> list[float]:
    n = len(values)
    draws = np.empty(10000, dtype=np.float64)
    for index in range(10000):
        sample = values[rng.integers(0, n, n)]
        draws[index] = statistic(sample)
    return [float(np.percentile(draws, 2.5)), float(np.percentile(draws, 97.5))]


def analyse(rows: list[dict]) -> dict:
    table = {(int(row["seed"]), row["group"], row["filename"]): float(row["lpips_alex_v01"]) for row in rows}
    names = [f"{i}.png" for i in range(100)]
    group_summary = {}
    for group in GROUPS:
        seed_means = [float(np.mean([table[(seed, group, name)] for name in names])) for seed in SEEDS]
        group_summary[group] = {
            "per_seed_mean": {str(seed): value for seed, value in zip(SEEDS, seed_means)},
            "three_seed_mean": float(np.mean(seed_means)),
            "between_seed_sample_sd": float(np.std(seed_means, ddof=1)),
        }
    comparison_results = {}
    for comparison_index, (candidate, control) in enumerate(COMPARISONS):
        candidate_values = np.array([np.mean([table[(seed, candidate, name)] for seed in SEEDS]) for name in names], dtype=np.float64)
        control_values = np.array([np.mean([table[(seed, control, name)] for seed in SEEDS]) for name in names], dtype=np.float64)
        paired = np.column_stack([candidate_values, control_values])
        rng_abs = np.random.default_rng(20260815 + comparison_index * 2)
        rng_rel = np.random.default_rng(20260816 + comparison_index * 2)
        absolute = candidate_values - control_values
        relative_improvement = 100.0 * (control_values.mean() - candidate_values.mean()) / control_values.mean()
        comparison_results[f"{candidate}_vs_{control}"] = {
            "candidate_minus_control": float(absolute.mean()),
            "candidate_minus_control_95ci": percentile_ci(absolute, rng_abs, np.mean),
            "ratio_of_means_relative_improvement_percent": float(relative_improvement),
            "relative_improvement_95ci": percentile_ci(
                paired,
                rng_rel,
                lambda sample: 100.0 * (sample[:, 1].mean() - sample[:, 0].mean()) / sample[:, 1].mean(),
            ),
            "images_candidate_lower": int(np.sum(candidate_values < control_values)),
            "images_equal": int(np.sum(candidate_values == control_values)),
            "images_total": 100,
            "classification": "POST_HOC_EXPLORATORY_NO_PASS_FAIL",
        }
    return {
        "status": "COMPLETE_POSTHOC_EXPLORATORY_LPIPS",
        "metric": "LPIPS AlexNet v0.1 (lower is better)",
        "independent_unit": "100 paired images",
        "seed_values_are_not_independent_n": True,
        "group_summary": group_summary,
        "comparisons": comparison_results,
        "confirmatory_interpretation_prohibited": True,
        "original_public_test_decision_modified": False,
    }


def write_report(analysis: dict) -> None:
    lines = [
        "# CEC公共测试LPIPS事后探索性分析",
        "",
        "> **强制标签：本分析为事后探索性分析（post hoc exploratory analysis）。LPIPS不是原公共测试预注册主要或次要指标，不参与原判定，不用于重新选模型或调参。**",
        "",
        "## 实现",
        "",
        "LPIPS 0.1.4，AlexNet主干，version 0.1；RGB sRGB浮点图像由[0,1]映射到[-1,1]，在原始完整尺寸上计算，越低越好。",
        "",
        "## 各组三种子结果",
        "",
        "| 方法 | LPIPS（三种子均值±种子间SD） |",
        "|---|---:|",
    ]
    for group in GROUPS:
        item = analysis["group_summary"][group]
        lines.append(f"| {group} | {item['three_seed_mean']:.6f} ± {item['between_seed_sample_sd']:.6f} |")
    lines += ["", "## 配对探索性比较", "", "| 比较 | 候选−对照 | 95% CI | 相对改善 | 95% CI | 改善图像 |", "|---|---:|---:|---:|---:|---:|"]
    for name, item in analysis["comparisons"].items():
        aci, rci = item["candidate_minus_control_95ci"], item["relative_improvement_95ci"]
        lines.append(
            f"| {name} | {item['candidate_minus_control']:+.6f} | [{aci[0]:+.6f}, {aci[1]:+.6f}] | "
            f"{item['ratio_of_means_relative_improvement_percent']:+.3f}% | [{rci[0]:+.3f}%, {rci[1]:+.3f}%] | "
            f"{item['images_candidate_lower']}/100 |"
        )
    lines += [
        "",
        "## 论文表述边界",
        "",
        "可以写：‘在原分析完成后，我们补充进行了事后探索性LPIPS分析，用于描述感知相似性；该指标未参与模型选择或原公共测试判定。’",
        "",
        "禁止写：‘LPIPS为预注册指标’、‘LPIPS证明主要门禁通过’或根据LPIPS结果继续修改模型。",
    ]
    REPORT.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    for path in (RESULT_CSV, ANALYSIS_JSON, REPORT, ACCESS, HASHES):
        if path.exists():
            raise RuntimeError(f"refusing to overwrite existing post hoc result: {path}")
    protocol = json.loads(PROTOCOL.read_text(encoding="utf-8"))
    if protocol.get("status") != "FROZEN_POSTHOC_EXPLORATORY_BEFORE_LPIPS_RUN":
        raise RuntimeError("invalid post hoc protocol status")
    prelock = json.loads(PRELOCK.read_text(encoding="utf-8"))
    if prelock.get("status") != "AUTHORIZED_TO_RUN_POSTHOC_EXPLORATORY_LPIPS_ONCE":
        raise RuntimeError("invalid pre-run authorization")
    if sha256_file(PROTOCOL) != prelock["protocol_sha256"] or sha256_file(Path(__file__)) != prelock["runner_sha256"]:
        raise RuntimeError("post hoc protocol or runner changed after pre-run lock")
    original_before = verify_original_archive()
    lock = json.loads(LOCK.read_text(encoding="utf-8"))
    for item in lock["locked_files"] + lock["weights"]:
        path = Path(item["path"])
        if not path.is_file() or sha256_file(path) != item["sha256"]:
            raise RuntimeError(f"frozen dependency changed: {path}")

    device = torch.device("cuda")
    lpips_model = build_frozen_lpips_alex(str(device))
    rows: list[dict] = []
    filenames = [f"{i}.png" for i in range(100)]
    with torch.inference_mode():
        for seed in SEEDS:
            parent50, parent100, capture, generic, ecf, bosr, combo = load_models(lock, seed, device)
            for image_index, name in enumerate(filenames, 1):
                low = read_rgb(INPUT / name)
                gt = read_rgb(GT / name)
                if low.shape != gt.shape:
                    raise RuntimeError(f"shape mismatch: {name}")
                image = torch.from_numpy(low).permute(2, 0, 1).unsqueeze(0).to(device)
                target = torch.from_numpy(gt).permute(2, 0, 1).unsqueeze(0).to(device)
                out50 = infer(parent50, image)
                ic = capture.value
                if ic is None:
                    raise RuntimeError("ECM capture failed")
                ic = ic[..., :image.shape[-2], :image.shape[-1]]
                outputs = {
                    "WTNet-50": torch.clamp(out50, 0, 1),
                    "WTNet-100": torch.clamp(infer(parent100, image), 0, 1),
                    "GenericHead": generic(image, ic, out50),
                    "ECF": ecf(image, ic, out50),
                    "BOSR-WTNet": bosr(image, ic, out50),
                    "ECF+BOSR": combo(image, ic, out50),
                }
                for group in GROUPS:
                    value = outputs[group]
                    output = value[0] if isinstance(value, tuple) else value
                    rows.append({"seed": seed, "group": group, "filename": name, "lpips_alex_v01": lpips_value(lpips_model, output, target)})
                print(f"seed={seed} image={image_index}/100", flush=True)
            capture.close()
            del parent50, parent100, generic, ecf, bosr, combo
            torch.cuda.empty_cache()

    if len(rows) != 1800 or len({(row["seed"], row["group"], row["filename"]) for row in rows}) != 1800:
        raise RuntimeError("post hoc result completeness failure")
    temporary = RESULT_CSV.with_suffix(".csv.tmp")
    with temporary.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=("seed", "group", "filename", "lpips_alex_v01"))
        writer.writeheader()
        writer.writerows(rows)
    os.replace(temporary, RESULT_CSV)
    analysis = analyse(rows)
    ANALYSIS_JSON.write_text(json.dumps(analysis, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    write_report(analysis)
    original_after = verify_original_archive()
    if original_before != original_after:
        raise RuntimeError("original archive hash set changed during post hoc analysis")
    access = {
        "status": "COMPLETE_POSTHOC_EXPLORATORY_ACCESS",
        "classification": "POST_HOC_EXPLORATORY_NOT_PREREGISTERED_ENDPOINT",
        "unique_test_images": 100,
        "result_rows": 1800,
        "input_reads": 300,
        "gt_reads": 300,
        "model_parameter_updates": 0,
        "model_selection_changes": 0,
        "original_public_test_files_modified": 0,
        "original_public_test_decision_modified": False,
    }
    ACCESS.write_text(json.dumps(access, indent=2) + "\n", encoding="utf-8")
    artifacts = [PROTOCOL, Path(__file__), RESULT_CSV, ANALYSIS_JSON, REPORT, ACCESS]
    HASHES.write_text(json.dumps({"status": "FROZEN_POSTHOC_LPIPS_ARTIFACTS", "files": [{"path": str(path), "bytes": path.stat().st_size, "sha256": sha256_file(path)} for path in artifacts]}, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps({"status": analysis["status"], "rows": len(rows), "primary": analysis["comparisons"]["BOSR-WTNet_vs_WTNet-50"]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
