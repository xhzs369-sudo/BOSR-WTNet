# 论文可直接使用的LPIPS表述

## 中文结果段落

在完成预注册公共测试分析后，我们补充开展了**事后探索性LPIPS分析**，用于描述感知特征空间中的图像相似性。该指标未参与模型选择，也未改变原预注册公共测试判定。LPIPS采用AlexNet主干（LPIPS v0.1），将RGB图像由[0,1]映射至[-1,1]并在原始完整尺寸上计算，数值越低越好。以100张配对测试图像为统计单位，并先在每张图像内平均三个训练种子的结果，BOSR-WTNet的平均LPIPS为0.042935，而WTNet-50为0.044299。BOSR-WTNet相对降低3.080%（配对图像级bootstrap 95% CI：2.218%–3.930%），其中72/100张图像获得更低的LPIPS。由于该分析为事后补充，其结果仅作为感知相似性的探索性支持证据，不作为预注册主要或次要终点。

## English Results paragraph

After completion of the preregistered public-test analysis, we conducted a **post hoc exploratory LPIPS analysis** to characterize perceptual feature-space similarity. LPIPS was not used for model selection and did not alter the original preregistered public-test decision. We used the AlexNet-based LPIPS model (version 0.1), mapped RGB images from [0,1] to [-1,1], and evaluated each image at its original full resolution; lower values indicate greater perceptual similarity. Treating the 100 paired test images as the independent analysis units and first averaging the three training-seed results within each image, BOSR-WTNet achieved a mean LPIPS of 0.042935 compared with 0.044299 for WTNet-50. This corresponded to a 3.080% relative reduction (paired image-level bootstrap 95% CI, 2.218% to 3.930%), with lower LPIPS in 72 of 100 images. Because this endpoint was added after the preregistered analysis, it is reported solely as exploratory perceptual-support evidence and not as a preregistered primary or secondary endpoint.

## Supplementary table title

**Supplementary Table X | Post hoc exploratory LPIPS results on the CEC public test set.** Values are three-training-seed means; between-seed variability is reported as sample SD. Paired effects use 100 images as the independent units after averaging seed-specific values within image. LPIPS was not included in the original preregistered endpoint hierarchy.

## 禁止使用的表述

- “LPIPS是原预注册主要/次要指标。”
- “LPIPS使原公共测试门禁由失败变为通过。”
- “LPIPS结果用于选择BOSR或继续调整模型。”
- “LPIPS改善证明了临床诊断质量改善。”
